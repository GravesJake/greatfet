.. cmake-module:: ../../Modules/FindBullet.cmake
