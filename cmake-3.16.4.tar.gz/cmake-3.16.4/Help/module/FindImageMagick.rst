.. cmake-module:: ../../Modules/FindImageMagick.cmake
